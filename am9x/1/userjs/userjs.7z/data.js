//data.js
/*
��������
items��������ϸĿ
tree���ô�����ϵ
*/
Items = function(){
  this.hashTable = {}
}
Items.prototype.add = function(data){
  this.hashTable[data.uid] = data;
}
Items.prototype.isMember = function(uid){
  return (this.hashTable[uid] !==undefined)
}

Tree = function(){
  this.hashTable ={};  
}
Tree.prototype.add = function(data){
  this.hashTable[data.uid] = data;
}
Tree.prototype.isMember = function(uid){
  return (this.hashTable[uid] !==undefined)
}
