function loadjq(callback){  
  var hd = document.getElementsByTagName('head')[0];  
   js = document.createElement('script');  
   js.setAttribute('type', 'text/javascript');  
   js.onload=function(evt,data){console.log("dataload",evt,data);callback()}
   js.src="http://www.w3school.com.cn/jquery/jquery.js"
   hd.appendChild(js);  
}
/*
$.get("http://weibo.com/1916655153/follow", function(result){
    console.log(result);
    res=result;
    uids=result.match(/uid=(\d+)&fnick=/g);
    console.log(uids);
  })
*/

function loadbi(_uid,xcallback){//ids
  $.get("http://weibo.com/"+_uid+"/follow?page=2", function(data){
    //console.log(data);
    gres=data;
     res={ids:[],users:[]};    
    htmls=data.match(/<li class=..clearfix S_line1..+?\/li>/g);
    if(htmls){
      //console.debug(htmls);
      $.each(htmls,function(i,x){
      //console.debug(i,x)
         _match=x.match(/uid=(\d+)&fnick=(.+?)&sex=[m,f]/);
         _p=x.match(/<img usercard.+?src=..(.+?).">/);
        _p = '"'+_p[1]+'"';
        _p = eval(_p);
         _g=x.match(/�����ע/);
        _g =!(_g==null);
         _entry={uid:_match[1],fnick:_match[2],img:_p,got:_g};
        res.users.push(_entry);
        res.ids.push(_match[1]);
      })
    }
    
    console.debug(res);
    xcallback(res);
  })
}
function processData(uid,data,parent){
//console.log("processData",uid,data,parent);
  var users=data.users;
  g_bi_list[uid]=data.ids;
  if(parent.level<max_level){
    $.each(users,function(i,x){
      var path = parent.path+"->"+(x.fnick);
     // if(x.uid==g_t){
     if(x.got){
        g_path.push(path);
      }
      else if(g_bi_list[x.uid] == undefined){
        var u = {uid:x.uid,level:parent.level+1,path:path};
        //console.log("=================",path);
        g_pool.push(u);
      }
   })
  }  
}
function grab(){
  //console.log(">>g_pool.length:",g_pool.length)
  var u = g_pool.shift();
  g_u = u;
  if (u!==undefined ){
  c++;
  console.log(">>No.",c,",  pool:",g_pool.length," ,  g_path.length:",g_path.length,",  Grab:",u)
    var uid = u.uid;
    var curlevel = u.level;
    //try{
    loadbi(uid,function(data){
      processData(uid,data,u);
      grab();
    })
    //}
    //catch(err){
     // console.log(err,err.message);
   // }
  }
}
var g_bi_list={};
var g_pool=[];
var g_path=[];
var c=0
var max_level=4;
var g_t="1116409355";
g_pool.push({uid:"2933482567",level:1,path:"Owner"});
loadjq(function(){grab()})
