﻿
$(document).ready(function (x) {
  imgdata = [];
  var elem = $("#myCanvas")[0];
   ctx = elem.getContext('2d');
    var elem2 = $("#myCanvas2")[0];
  var ctx2 = elem2.getContext('2d');
  $("#imgcopy").live("click",function(e,v){
    var dataURL = elem.toDataURL("image/png");
    imageCopy(ctx2,dataURL)
  })
  
})